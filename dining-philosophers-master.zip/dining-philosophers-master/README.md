# Dining Philosophers

---

![alt text](https://firebasestorage.googleapis.com/v0/b/mi-umsa-1ca4e.appspot.com/o/images%2Fdining-philosophers.png?alt=media&token=f2e4350d-e6c1-4937-b4b4-80e0698ad6a9)
